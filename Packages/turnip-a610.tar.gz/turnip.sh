#!/bin/bash
sudo cp -r ./usr /
